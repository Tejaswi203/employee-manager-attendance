Attendance System - Minimal Complete Scaffold
-------------------------------------------
What's included:
- backend/ : Node.js + Express + Mongoose API with auth and attendance endpoints + seed script
- frontend/: Minimal React app to login and mark attendance

Quick start (backend):
1. cd backend
2. npm install
3. create .env with values from .env.example
4. npm run seed   # optional, creates manager and 2 employees
5. npm run dev    # or npm start

Quick start (frontend):
1. cd frontend
2. npm install
3. npm start
Note: frontend expects backend at http://localhost:5000 by default. Adjust REACT_APP_API_URL if needed.

Download this zip and run locally. If you want me to include more features (CSV export, manager UI, calendar), tell me and I'll update the zip.

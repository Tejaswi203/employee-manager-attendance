const jwt = require('jsonwebtoken');
module.exports = function(req,res,next){
  const token = req.header('Authorization')?.replace('Bearer ','') || req.body.token || req.query.token;
  if(!token) return res.status(401).json({ message: 'No token' });
  try{
    const data = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    req.user = data;
    next();
  } catch(e){
    return res.status(401).json({ message: 'Invalid token' });
  }
};

const mongoose = require('mongoose');
const attendanceSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  date: { type: String, required: true }, // YYYY-MM-DD
  checkInTime: Date,
  checkOutTime: Date,
  status: { type: String, enum: ['present','absent','late','half-day'], default: 'absent' },
  totalHours: Number,
  createdAt: { type: Date, default: Date.now }
});
attendanceSchema.index({ userId:1, date:1 }, { unique: true });
module.exports = mongoose.model('Attendance', attendanceSchema);

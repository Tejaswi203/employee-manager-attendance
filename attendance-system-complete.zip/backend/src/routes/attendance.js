const express = require('express');
const router = express.Router();
const dayjs = require('dayjs');
const auth = require('../middlewares/auth');
const Attendance = require('../models/Attendance');
const User = require('../models/User');

// checkin
router.post('/checkin', auth, async (req,res)=>{
  try{
    const userId = req.user.id;
    const date = dayjs().format('YYYY-MM-DD');
    let att = await Attendance.findOne({ userId, date });
    if(att && att.checkInTime) return res.status(400).json({ message: 'Already checked in' });
    if(!att) att = new Attendance({ userId, date });
    att.checkInTime = new Date();
    // late threshold 9:30
    const cutoff = dayjs().hour(9).minute(30);
    if(dayjs().isAfter(cutoff)) att.status = 'late';
    else att.status = 'present';
    await att.save();
    res.json(att);
  }catch(e){ console.error(e); res.status(500).json({ message: 'Server error' }); }
});

// checkout
router.post('/checkout', auth, async (req,res)=>{
  try{
    const userId = req.user.id;
    const date = dayjs().format('YYYY-MM-DD');
    let att = await Attendance.findOne({ userId, date });
    if(!att || !att.checkInTime) return res.status(400).json({ message: 'No check-in found' });
    if(att.checkOutTime) return res.status(400).json({ message: 'Already checked out' });
    att.checkOutTime = new Date();
    const diffMs = att.checkOutTime - att.checkInTime;
    const hours = diffMs / (1000*60*60);
    att.totalHours = Number(hours.toFixed(2));
    if(att.totalHours < 4) att.status = 'half-day';
    await att.save();
    res.json(att);
  }catch(e){ console.error(e); res.status(500).json({ message: 'Server error' }); }
});

// my history
router.get('/my-history', auth, async (req,res)=>{
  try{
    const userId = req.user.id;
    const rows = await Attendance.find({ userId }).sort({ date:-1 });
    res.json(rows);
  }catch(e){ console.error(e); res.status(500).json({ message: 'Server error' }); }
});

// manager: all (very basic filter by date)
router.get('/all', auth, async (req,res)=>{
  try{
    if(req.user.role !== 'manager') return res.status(403).json({ message: 'Forbidden' });
    const { from, to } = req.query;
    const q = {};
    if(from && to) q.date = { $gte: from, $lte: to };
    const rows = await Attendance.find(q).populate('userId','name employeeId department').sort({ date:-1 }).limit(1000);
    res.json(rows);
  }catch(e){ console.error(e); res.status(500).json({ message: 'Server error' }); }
});

module.exports = router;

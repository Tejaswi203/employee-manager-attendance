// Simple seed: create one manager and two employees
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../src/models/User');
const Attendance = require('../src/models/Attendance');
require('dotenv').config();
const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/attendance';
async function run(){
  await mongoose.connect(MONGO);
  console.log('connected');
  await User.deleteMany({});
  await Attendance.deleteMany({});
  const mpass = await bcrypt.hash('manager123',10);
  const epass = await bcrypt.hash('employee123',10);
  const manager = await User.create({ name:'Manager One', email:'manager@test.com', password:mpass, role:'manager', employeeId:'MGR001', department:'Admin' });
  const emp1 = await User.create({ name:'Alice Employee', email:'alice@test.com', password:epass, role:'employee', employeeId:'EMP001', department:'Engineering' });
  const emp2 = await User.create({ name:'Bob Employee', email:'bob@test.com', password:epass, role:'employee', employeeId:'EMP002', department:'Engineering' });
  console.log('users created', manager.email, emp1.email, emp2.email);
  // create one attendance for today for emp1 checked in earlier and checked out
  const now = new Date();
  await Attendance.create({ userId: emp1._id, date: require('dayjs')().format('YYYY-MM-DD'), checkInTime: new Date(now - 1000*60*60*8), checkOutTime: now, status:'present', totalHours:8 });
  console.log('seed done');
  process.exit(0);
}
run().catch(e=>{ console.error(e); process.exit(1); });

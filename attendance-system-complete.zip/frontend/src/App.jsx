import React, { useState, useEffect } from 'react';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
function App(){
  const [token, setToken] = useState(localStorage.getItem('token'));
  useEffect(()=>{ setToken(localStorage.getItem('token')); },[]);
  if(!token) return <Login onLogin={(t)=>{ localStorage.setItem('token', t); setToken(t); window.location.reload(); }} />;
  return <Dashboard onLogout={()=>{ localStorage.removeItem('token'); window.location.reload(); }} />;
}
export default App;

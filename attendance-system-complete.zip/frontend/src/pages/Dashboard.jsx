import React, { useEffect, useState } from 'react';
import api from '../api/axios';
export default function Dashboard({ onLogout }){
  const [me, setMe] = useState(null);
  const [history, setHistory] = useState([]);
  useEffect(()=>{ api.get('/api/auth/me').then(r=>setMe(r.data.user)).catch(()=>onLogout()); api.get('/api/attendance/my-history').then(r=>setHistory(r.data)).catch(()=>{}); },[]);
  const doCheckIn = async ()=>{ await api.post('/api/attendance/checkin'); const r = await api.get('/api/attendance/my-history'); setHistory(r.data); };
  const doCheckOut = async ()=>{ await api.post('/api/attendance/checkout'); const r = await api.get('/api/attendance/my-history'); setHistory(r.data); };
  return (<div style={{padding:20}}><h2>Dashboard</h2><button onClick={onLogout}>Logout</button>{me && <div><strong>{me.name}</strong> ({me.role})</div>}<div style={{marginTop:10}}><button onClick={doCheckIn}>Check In</button> <button onClick={doCheckOut}>Check Out</button></div><h3>History</h3><table border="1" cellPadding="6"><thead><tr><th>Date</th><th>Status</th><th>Check In</th><th>Check Out</th><th>Hours</th></tr></thead><tbody>{history.map(h=>(<tr key={h._id}><td>{h.date}</td><td>{h.status}</td><td>{h.checkInTime? new Date(h.checkInTime).toLocaleTimeString() : '-'}</td><td>{h.checkOutTime? new Date(h.checkOutTime).toLocaleTimeString() : '-'}</td><td>{h.totalHours||'-'}</td></tr>))}</tbody></table></div>);
}

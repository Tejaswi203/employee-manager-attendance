import React, { useState } from 'react';
import api from '../api/axios';
export default function Login({ onLogin }){
  const [email,setEmail]=useState('alice@test.com');
  const [password,setPassword]=useState('employee123');
  const [err,setErr]=useState('');
  const submit=async(e)=>{ e.preventDefault(); try{ const res = await api.post('/api/auth/login',{ email,password }); onLogin(res.data.token); }catch(e){ setErr(e.response?.data?.message || 'Login failed'); } };
  return (<div style={{padding:20}}><h2>Login</h2><form onSubmit={submit}><div><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="email" /></div><div><input value={password} onChange={e=>setPassword(e.target.value)} placeholder="password" type="password" /></div><button type="submit">Login</button></form>{err && <p style={{color:'red'}}>{err}</p>}<p>Use seeded accounts: manager@test.com / manager123  OR alice@test.com / employee123</p></div>);
}
